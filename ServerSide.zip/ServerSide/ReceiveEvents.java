import java.awt.Robot;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.Scanner;

public class ReceiveEvents extends Thread {
    
    private Socket socket = null;
    private Robot robot = null;
    private volatile boolean continueLoop = true;
    
    public ReceiveEvents(Socket socket, Robot robot) {
        this.socket = socket;
        this.robot = robot;
        start();
    }
    
    public void stopReceiving() {
        continueLoop = false;
        this.interrupt();
    }
    
    @Override
    public void run() {

         try {
        InputStream is = socket.getInputStream();
        System.out.println("=== DEBUG: First 100 bytes from client ===");
        
        byte[] buffer = new byte[100];
        int bytesRead = is.read(buffer);
        
        // Print hex and text representation
        System.out.print("Hex: ");
        for (int i = 0; i < bytesRead; i++) {
            System.out.printf("%02X ", buffer[i] & 0xFF);
        }
        System.out.println();
        
        System.out.print("Text: ");
        for (int i = 0; i < bytesRead; i++) {
            char c = (char) buffer[i];
            System.out.print(c >= 32 && c < 127 ? c : '.');
        }
        System.out.println("\n========================================");
        
        // Now continue with your normal reading...
        
    } catch (Exception e) {
        e.printStackTrace();
    }

        try (Scanner scanner = new Scanner(socket.getInputStream())) {
            System.out.println("Event receiver started. Waiting for commands...");
            
            while (continueLoop && !Thread.currentThread().isInterrupted() && scanner.hasNextLine()) {
                try {
                    String line = scanner.nextLine().trim();
                    if (line.isEmpty()) {
                        continue;
                    }
                    
                    int command = Integer.parseInt(line);
                    processCommand(command, scanner);
                    
                } catch (NumberFormatException e) {
                    System.err.println("Invalid number format. Line: " + e.getMessage());
                } catch (Exception e) {
                    System.err.println("Error processing command: " + e.getMessage());
                    e.printStackTrace();
                }
            }
            
            System.out.println("Event receiver stopping.");
            
        } catch (Exception e) {
            if (continueLoop) {
                System.err.println("Event receiver error: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    
    private void processCommand(int command, Scanner scanner) throws IOException {
        System.out.println("Processing command: " + command);
        
        switch (command) {
            case -1: // PRESS_MOUSE
                if (scanner.hasNextLine()) {
                    int button = Integer.parseInt(scanner.nextLine().trim());
                    System.out.println("  Mouse press button: " + button);
                    robot.mousePress(button);
                }
                break;
                
            case -2: // RELEASE_MOUSE
                if (scanner.hasNextLine()) {
                    int button = Integer.parseInt(scanner.nextLine().trim());
                    System.out.println("  Mouse release button: " + button);
                    robot.mouseRelease(button);
                }
                break;
                
            case -3: // PRESS_KEY
                if (scanner.hasNextLine()) {
                    int keyCode = Integer.parseInt(scanner.nextLine().trim());
                    System.out.println("  Key press: " + keyCode);
                    robot.keyPress(keyCode);
                }
                break;
                
            case -4: // RELEASE_KEY
                if (scanner.hasNextLine()) {
                    int keyCode = Integer.parseInt(scanner.nextLine().trim());
                    System.out.println("  Key release: " + keyCode);
                    robot.keyRelease(keyCode);
                }
                break;
                
            case -5: // MOVE_MOUSE
                if (scanner.hasNextLine()) {
                    int x = Integer.parseInt(scanner.nextLine().trim());
                    int y = Integer.parseInt(scanner.nextLine().trim());
                    System.out.println("  Mouse move to: " + x + ", " + y);
                    robot.mouseMove(x, y);
                }
                break;
                
            default:
                System.err.println("Unknown command: " + command);
                // Try to skip any following data for this unknown command
                if (scanner.hasNextLine()) scanner.nextLine();
                if (scanner.hasNextLine() && (command == -5)) scanner.nextLine();
                break;
        }
    }
    
    private void cleanup() {
        continueLoop = false;
        System.out.println("Event receiver cleaned up.");
    }
}