import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;  // Added import
import java.net.Socket;

public class SendScreen extends Thread {  // Extend Thread
    
    private Socket socket = null;
    private Robot robot = null;
    private Rectangle rectangle = null;
    private volatile boolean continueLoop = true;  // boolean, not Boolean for primitives
    private OutputStream oos = null;
    private int fpsDelay = 100;  // Delay between frames in ms (10 FPS = 100ms)
    
    // Fixed: Rectangle spelling
    public SendScreen(Socket socket, Robot robot, Rectangle rect) {
        this.socket = socket;
        this.robot = robot;
        this.rectangle = rect;
        start();  // Now this works because we extend Thread
    }
    
    // Stop the screen capture
    public void stopSending() {
        continueLoop = false;
        this.interrupt();  // Interrupt the thread
    }
    
    @Override
    public void run() {
        try {
            oos = socket.getOutputStream();
            System.out.println("Screen sharing started...");
            
            while (continueLoop && !Thread.currentThread().isInterrupted()) {
                // Capture screen
                BufferedImage image = robot.createScreenCapture(rectangle);
                
                // Compress and send image
                if (ImageIO.write(image, "jpeg", oos)) {
                    oos.flush();  // Important: flush the stream
                } else {
                    System.err.println("No appropriate JPEG writer found!");
                }
                
                // Delay to control FPS
                try {
                    Thread.sleep(fpsDelay);
                } catch (InterruptedException e) {
                    // Thread was interrupted, exit gracefully
                    System.out.println("Screen sharing interrupted");
                    break;
                }
                
                // Optional: Reduce image quality for better performance
                // You could resize or compress the image here
            }
            
        } catch (IOException e) {
            if (continueLoop) {  // Only print if we didn't intentionally stop
                System.err.println("Screen sharing error: " + e.getMessage());
                e.printStackTrace();
            }
        } finally {
            // Cleanup resources
            cleanup();
        }
    }
    
    private void cleanup() {
        continueLoop = false;
        
        try {
            if (oos != null) {
                oos.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        System.out.println("Screen sharing stopped.");
    }
    
    // Optional: Set FPS (frames per second)
    public void setFPS(int fps) {
        if (fps > 0 && fps <= 60) {  // Reasonable limits
            this.fpsDelay = 1000 / fps;  // Convert FPS to ms delay
        }
    }
    
    // Optional: Change capture area
    public void setCaptureArea(Rectangle newRect) {
        this.rectangle = newRect;
    }
    
    // Optional: Add image quality/compression settings
    public void setImageQuality(float quality) {
        // You could use ImageWriter with compression settings here
        // This requires more advanced ImageIO usage
    }
}