import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class ServerSide {
    
    public static void main(String[] args) {
        // Show password dialog first
        SetPassword passwordFrame = new SetPassword();
        passwordFrame.setSize(300, 100);
        passwordFrame.setLocation(500, 300);
        passwordFrame.setVisible(true);
        
        // Wait for password to be set
        // Note: This is a blocking approach. Better would be using callbacks
        System.out.println("Server application started. Set password to begin.");
    }
    
    // Method to be called from SetPassword when password is set
    public static void startServer(String password) {
        System.out.println("Starting server with password: " + password);
        
        int port = 4907;
        try {
            // Start the actual server that listens for connections
            new InitConnection(port, password);
            System.out.println("Server is now listening on port " + port);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, 
                "Failed to start server: " + e.getMessage(),
                "Server Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}