import java.awt.BorderLayout;
import java.awt.GridLayout; // Changed from GridBagLayout
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SetPassword extends JFrame implements ActionListener {
    
    static String port = "4907";
    JButton submit;
    JPanel panel;
    JTextField text1, text2;
    String value1, value2;
    JLabel label, label1, label2;

    SetPassword() {
        label1 = new JLabel();
        label1.setText("Set Password");
        text1 = new JTextField(15);
        label = new JLabel(); // Fixed: JLabel not JTextField
        submit = new JButton("Submit");
        
        // Use GridLayout instead of GridBagLayout
        panel = new JPanel(new GridLayout(2, 2)); // 2 rows, 2 columns
        panel.add(label1);
        panel.add(text1);
        panel.add(label); // This label is empty
        panel.add(submit);
        
        add(panel, BorderLayout.CENTER);
        submit.addActionListener(this);
        setTitle("Setting password for client");
    }

    // Fixed: Changed parameter from javafx.event.ActionEvent to java.awt.event.ActionEvent
    public void actionPerformed(ActionEvent e) {
        value1 = text1.getText();
        dispose();
        new InitConnection(Integer.parseInt(port), value1);
    }

    public String getValue1() {
        return value1;
    }

    public static void main(String[] args) {
        SetPassword frame1 = new SetPassword();
        frame1.setSize(300, 80);
        frame1.setLocation(500, 300);
        frame1.setVisible(true);
    }
}