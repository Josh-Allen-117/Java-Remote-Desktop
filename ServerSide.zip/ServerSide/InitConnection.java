import java.awt.Dimension;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class InitConnection {
    
    private ServerSocket socket = null;
    private String width = "";
    private String height = "";
    private Robot robot = null;          // Moved to instance variable
    private Rectangle rectangle = null;  // Moved to instance variable
    
    public InitConnection(int port, String passwordValue) {
        try {
            System.out.println("Starting server on port " + port);
            socket = new ServerSocket(port);
            
            GraphicsEnvironment gEnv = GraphicsEnvironment.getLocalGraphicsEnvironment();
            GraphicsDevice gDev = gEnv.getDefaultScreenDevice();
            
            Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
            this.width = "" + (int)dim.getWidth();
            this.height = "" + (int)dim.getHeight();
            
            // Initialize instance variables
            this.rectangle = new Rectangle(dim);
            this.robot = new Robot(gDev);
            
            System.out.println("Server ready. Screen resolution: " + width + "x" + height);
            
            // Create final local references for use in lambda
            final Robot finalRobot = this.robot;
            final Rectangle finalRectangle = this.rectangle;
            final String finalPassword = passwordValue;
            
            // Main server loop
            while(true) {
                System.out.println("\nWaiting for client connection...");
                Socket clientSocket = socket.accept();
                System.out.println("Client connected from: " + clientSocket.getInetAddress().getHostAddress());
                
                // Handle each client in a separate thread
                new Thread(() -> {
                    handleClient(clientSocket, finalPassword, finalRobot, finalRectangle);
                }).start();
            }
            
        } catch(IOException e) {
            System.err.println("Network error: " + e.getMessage());
            e.printStackTrace();
        } catch(Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Cleanup resources
            try {
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    // This method handles individual client connections
    private void handleClient(Socket clientSocket, String password, Robot robot, Rectangle rectangle) {
        DataInputStream passwordInput = null;
        DataOutputStream verifyOutput = null;
        
        try {
            passwordInput = new DataInputStream(clientSocket.getInputStream());
            verifyOutput = new DataOutputStream(clientSocket.getOutputStream());
            
            // Read and verify password
            String receivedPassword = passwordInput.readUTF();
            System.out.println("Password attempt from " + clientSocket.getInetAddress() + ": " + 
                             (receivedPassword.equals(password) ? "CORRECT" : "INCORRECT"));
            
            if(receivedPassword.equals(password)) {
                System.out.println("Authentication successful. Sending screen info...");
                verifyOutput.writeUTF("valid");
                verifyOutput.writeUTF(width);
                verifyOutput.writeUTF(height);
                verifyOutput.flush();
                
                // Start ping handler thread
                System.out.println("Starting ping handler for latency measurement...");
                new Thread(new PingHandler(clientSocket)).start();
                
                // Start screen sharing and event handling
                System.out.println("Starting screen sharing...");
                new SendScreen(clientSocket, robot, rectangle);
                
                System.out.println("Starting event receiver...");
                new ReceiveEvents(clientSocket, robot);
                
                System.out.println("Remote control session active for " + clientSocket.getInetAddress());
                
            } else {
                System.out.println("Authentication failed. Closing connection.");
                verifyOutput.writeUTF("invalid");
                verifyOutput.flush();
                clientSocket.close();
            }
            
        } catch(IOException e) {
            System.err.println("Client handler error for " + clientSocket.getInetAddress() + ": " + e.getMessage());
            try {
                if (!clientSocket.isClosed()) {
                    clientSocket.close();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    // This inner class handles ping requests for latency measurement
    class PingHandler implements Runnable {
        private Socket socket;
        private DataInputStream input;
        private DataOutputStream output;
        
        public PingHandler(Socket socket) {
            this.socket = socket;
        }
        
        @Override
        public void run() {
            try {
                input = new DataInputStream(socket.getInputStream());
                output = new DataOutputStream(socket.getOutputStream());
                
                System.out.println("Ping handler started for " + socket.getInetAddress());
                
                while (!socket.isClosed()) {
                    try {
                        // Read the command
                        int command = input.readInt();
                        
                        // Check if it's a ping request
                        if (command == Commands.PING_REQUEST.getAbbrev()) {
                            // Read the timestamp sent by client
                            long timestamp = input.readLong();
                            
                            // Calculate server processing time (optional)
                            long serverProcessingTime = System.currentTimeMillis() - timestamp;
                            
                            // Send back the ping response with original timestamp
                            output.writeInt(Commands.PING_RESPONSE.getAbbrev());
                            output.writeLong(timestamp);
                            output.flush();
                            
                            // Log occasional ping responses (once every 10 pings)
                            if (Math.random() < 0.1) { // 10% chance to log
                                System.out.println("Ping response sent to " + socket.getInetAddress() + 
                                                 " | Server processing: " + serverProcessingTime + "ms");
                            }
                        }
                    } catch (IOException e) {
                        // Client disconnected
                        System.out.println("Ping handler: Client " + socket.getInetAddress() + " disconnected");
                        break;
                    }
                }
                
            } catch (Exception e) {
                if (!socket.isClosed()) {
                    System.err.println("Ping handler error: " + e.getMessage());
                }
            } finally {
                System.out.println("Ping handler terminated for " + socket.getInetAddress());
            }
        }
    }
    
    // Optional: If you implement a GUI
    private void drawGUI() {
        // Implement your GUI here if needed
    }
    
    // Main method to test
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java InitConnection <port> <password>");
            System.exit(1);
        }
        
        int port = Integer.parseInt(args[0]);
        String password = args[1];
        new InitConnection(port, password);
    }
}