public enum Commands {
    PRESS_MOUSE(-1),
    RELEASE_MOUSE(-2),
    PRESS_KEY(-3),
    RELEASE_KEY(-4),
    MOVE_MOUSE(-5),
    PING_REQUEST(-6),     // Added: Client sends ping request
    PING_RESPONSE(-7);    // Added: Server sends ping response
    
    private int abbrev;
    
    Commands(int abbrev) {
        this.abbrev = abbrev;
    }
    
    public int getAbbrev() {
        return abbrev;
    }
}