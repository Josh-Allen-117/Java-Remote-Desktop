import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class Authentication extends JFrame implements ActionListener {
    private Socket cSocket = null;
    private JButton submit;
    private JPanel mainPanel, latencyPanel;
    private JLabel label, label1, latencyLabel;
    private JPasswordField passwordField;
    private String width = "", height = "";
    private volatile long lastPingTime = 0;
    private volatile long currentLatency = 0;
    private ScheduledExecutorService pingScheduler;
    private DataOutputStream outputStream;
    private DataInputStream inputStream;
    
    Authentication(Socket cSocket) {
        this.cSocket = cSocket;
        
        // Main components
        label1 = new JLabel("Password:");
        passwordField = new JPasswordField(15);
        label = new JLabel("");
        submit = new JButton("Submit");
        
        // Latency display
        latencyLabel = new JLabel("Latency: -- ms");
        latencyLabel.setForeground(Color.BLUE);
        latencyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        latencyPanel.add(new JLabel("Connection Status: "));
        latencyPanel.add(latencyLabel);
        
        // Main panel layout
        mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        
        JPanel authPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        authPanel.add(label1);
        authPanel.add(passwordField);
        authPanel.add(submit);
        
        mainPanel.add(authPanel);
        mainPanel.add(Box.createVerticalStrut(10));
        mainPanel.add(latencyPanel);
        
        add(mainPanel, BorderLayout.CENTER);
        add(label, BorderLayout.SOUTH);
        
        submit.addActionListener(this);
        setTitle("Remote Desktop Login");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        // Start ping thread for connection testing
        startLatencyMeasurement();
    }
    
    private void startLatencyMeasurement() {
        pingScheduler = Executors.newSingleThreadScheduledExecutor();
        
        pingScheduler.scheduleAtFixedRate(() -> {
            if (cSocket != null && !cSocket.isClosed() && outputStream != null) {
                try {
                    lastPingTime = System.currentTimeMillis();
                    outputStream.writeUTF("PING");
                    outputStream.flush();
                } catch (IOException e) {
                    // Connection lost
                    SwingUtilities.invokeLater(() -> {
                        latencyLabel.setText("Latency: Disconnected");
                        latencyLabel.setForeground(Color.RED);
                    });
                }
            }
        }, 0, 2, TimeUnit.SECONDS); // Ping every 2 seconds
    }
    
    private void stopLatencyMeasurement() {
        if (pingScheduler != null && !pingScheduler.isShutdown()) {
            pingScheduler.shutdown();
        }
    }
    
    public void actionPerformed(ActionEvent ae) {
        String password = new String(passwordField.getPassword());
        
        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Please enter a password", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            outputStream = new DataOutputStream(cSocket.getOutputStream());
            inputStream = new DataInputStream(cSocket.getInputStream());
            
            // Start a thread to listen for PONG responses
            new Thread(() -> {
                try {
                    while (!cSocket.isClosed()) {
                        String response = inputStream.readUTF();
                        if (response.equals("PONG")) {
                            long now = System.currentTimeMillis();
                            currentLatency = now - lastPingTime;
                            
                            // Update UI on EDT
                            SwingUtilities.invokeLater(() -> {
                                latencyLabel.setText(String.format("Latency: %d ms", currentLatency));
                                
                                // Color coding based on latency
                                if (currentLatency < 50) {
                                    latencyLabel.setForeground(Color.GREEN);
                                } else if (currentLatency < 100) {
                                    latencyLabel.setForeground(Color.ORANGE);
                                } else {
                                    latencyLabel.setForeground(Color.RED);
                                }
                            });
                        }
                    }
                } catch (IOException e) {
                    // Connection closed
                }
            }).start();
            
            // Send password
            outputStream.writeUTF(password);
            outputStream.flush();
            
            String verify = inputStream.readUTF();
            
            if (verify.equals("valid")) {
                width = inputStream.readUTF();
                height = inputStream.readUTF();
                
                // Stop pre-auth ping and start CreateFrame
                stopLatencyMeasurement();
                new CreateFrame(cSocket, width, height, this);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Password is incorrect", 
                    "Authentication Error", 
                    JOptionPane.ERROR_MESSAGE);
                passwordField.setText("");
                passwordField.requestFocus();
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, 
                "Connection error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
            stopLatencyMeasurement();
            dispose();
        }
    }
}