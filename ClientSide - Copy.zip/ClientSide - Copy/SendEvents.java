import java.awt.event.*;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JPanel;

class SendEvents implements KeyListener, MouseMotionListener, MouseListener, MouseWheelListener {
    private Socket cSocket;
    private JPanel cPanel;
    private DataOutputStream writer;
    private double w, h;
    private volatile long eventLatency = 0;
    
    SendEvents(Socket s, JPanel p, String width, String height) {
        cSocket = s;
        cPanel = p;
        
        try {
            w = Double.parseDouble(width.trim());
            h = Double.parseDouble(height.trim());
        } catch (NumberFormatException e) {
            w = 1920;
            h = 1080;
        }
        
        try {
            writer = new DataOutputStream(cSocket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        cPanel.addKeyListener(this);
        cPanel.addMouseListener(this);
        cPanel.addMouseMotionListener(this);
        cPanel.addMouseWheelListener(this);
        cPanel.setFocusable(true);
        cPanel.requestFocusInWindow();
    }
    
    private void sendCommandWithTimestamp(int command, int... params) {
        if (writer == null) return;
        
        try {
            long timestamp = System.currentTimeMillis();
            
            synchronized (writer) {
                writer.writeInt(command);
                writer.writeLong(timestamp); // Send timestamp for latency calculation
                
                for (int param : params) {
                    writer.writeInt(param);
                }
                writer.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void mouseMoved(MouseEvent e) {
        double xScale = (w > 0) ? w / cPanel.getWidth() : 1.0;
        double yScale = (h > 0) ? h / cPanel.getHeight() : 1.0;
        
        sendCommandWithTimestamp(
            Commands.MOVE_MOUSE.getAbbrev(),
            (int)(e.getX() * xScale),
            (int)(e.getY() * yScale)
        );
    }
    
    @Override
    public void mouseDragged(MouseEvent e) {
        mouseMoved(e);
    }
    
    @Override
    public void mousePressed(MouseEvent e) {
        int button = e.getButton();
        int xButton = 16; // Left button
        
        if (button == MouseEvent.BUTTON3) {
            xButton = 4; // Right button
        } else if (button == MouseEvent.BUTTON2) {
            xButton = 8; // Middle button
        }
        
        sendCommandWithTimestamp(Commands.PRESS_MOUSE.getAbbrev(), xButton);
    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        int button = e.getButton();
        int xButton = 16;
        
        if (button == MouseEvent.BUTTON3) {
            xButton = 4;
        } else if (button == MouseEvent.BUTTON2) {
            xButton = 8;
        }
        
        sendCommandWithTimestamp(Commands.RELEASE_MOUSE.getAbbrev(), xButton);
    }
    
    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        // You can implement mouse wheel support here
        // This would require adding a new command to the enum
    }
    
    @Override
    public void keyPressed(KeyEvent e) {
        sendCommandWithTimestamp(Commands.PRESS_KEY.getAbbrev(), e.getKeyCode());
    }
    
    @Override
    public void keyReleased(KeyEvent e) {
        sendCommandWithTimestamp(Commands.RELEASE_KEY.getAbbrev(), e.getKeyCode());
    }
    
    // Other required methods (empty implementations)
    @Override public void mouseClicked(MouseEvent e) {}
    @Override public void mouseEntered(MouseEvent e) {}
    @Override public void mouseExited(MouseEvent e) {}
    @Override public void keyTyped(KeyEvent e) {}
}