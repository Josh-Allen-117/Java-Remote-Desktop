import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

class ReceivingScreen extends Thread {
    private InputStream oin;
    private JPanel cPanel;
    private CreateFrame parentFrame;
    private AtomicInteger frameCount = new AtomicInteger(0);
    private AtomicLong lastFpsUpdate = new AtomicLong(System.currentTimeMillis());
    private volatile boolean continueLoop = true;
    
    public ReceivingScreen(InputStream in, JPanel p, CreateFrame parent) {
        oin = in;
        cPanel = p;
        parentFrame = parent;
        start();
    }
    
    @Override
    public void run() {
        try {
            byte[] bytes = new byte[1024 * 1024];
            
            while (continueLoop) {
                int count = 0;
                
                // Read JPEG image data
                do {
                    int read = oin.read(bytes, count, bytes.length - count);
                    if (read == -1) {
                        continueLoop = false;
                        break;
                    }
                    count += read;
                } while (!(count > 4 && bytes[count - 2] == (byte) -1 && bytes[count - 1] == (byte) -39));
                
                if (!continueLoop) break;
                
                // Decode and display image
                BufferedImage image = ImageIO.read(new ByteArrayInputStream(bytes, 0, count));
                if (image != null) {
                    Image scaledImage = image.getScaledInstance(cPanel.getWidth(), cPanel.getHeight(), Image.SCALE_SMOOTH);
                    
                    SwingUtilities.invokeLater(() -> {
                        Graphics graphics = cPanel.getGraphics();
                        if (graphics != null) {
                            graphics.drawImage(scaledImage, 0, 0, cPanel.getWidth(), cPanel.getHeight(), cPanel);
                        }
                    });
                    
                    // Update FPS counter
                    updateFPSCounter();
                }
            }
        } catch (IOException e) {
            if (continueLoop) {
                e.printStackTrace();
            }
        }
    }
    
    private void updateFPSCounter() {
        int count = frameCount.incrementAndGet();
        long now = System.currentTimeMillis();
        long lastUpdate = lastFpsUpdate.get();
        
        // Update FPS every second
        if (now - lastUpdate >= 1000) {
            if (lastFpsUpdate.compareAndSet(lastUpdate, now)) {
                int fps = count;
                frameCount.set(0);
                
                // Update FPS display in parent frame
                if (parentFrame != null) {
                    parentFrame.setFPS(fps);
                }
            }
        }
    }
    
    public void stopReceiving() {
        continueLoop = false;
        this.interrupt();
    }
}