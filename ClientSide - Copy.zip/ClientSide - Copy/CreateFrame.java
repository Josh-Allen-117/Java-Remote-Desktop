import javax.swing.*;
import java.awt.*;
import java.beans.PropertyVetoException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class CreateFrame extends Thread {
    private String width, height;
    private JFrame frame;
    private JDesktopPane desktop;
    private Socket cSocket;
    private JInternalFrame interFrame;
    private JPanel cPanel;
    private JPanel statusBar;
    private JLabel latencyLabel;
    private JLabel fpsLabel;
    private JLabel resolutionLabel;
    private Authentication authWindow;
    private volatile long currentLatency = 0;
    private ScheduledExecutorService pingScheduler;
    private DataOutputStream outputStream;
    private DataInputStream inputStream;
    
    public CreateFrame(Socket cSocket, String width, String height, Authentication authWindow) {
        this.width = width;
        this.height = height;
        this.cSocket = cSocket;
        this.authWindow = authWindow;
        start();
    }
    
    public void drawGUI() {
        frame = new JFrame("Remote Desktop Client");
        
        // Create status bar
        statusBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        statusBar.setBackground(Color.LIGHT_GRAY);
        
        latencyLabel = new JLabel("Latency: -- ms");
        fpsLabel = new JLabel("FPS: --");
        resolutionLabel = new JLabel("Server: " + width + "x" + height);
        
        statusBar.add(latencyLabel);
        statusBar.add(Box.createHorizontalStrut(20));
        statusBar.add(fpsLabel);
        statusBar.add(Box.createHorizontalStrut(20));
        statusBar.add(resolutionLabel);
        
        // Main desktop
        desktop = new JDesktopPane();
        desktop.setBackground(Color.GRAY);
        
        interFrame = new JInternalFrame("Remote Screen", true, true, true);
        cPanel = new JPanel();
        cPanel.setBackground(Color.BLACK);
        cPanel.setFocusable(true);
        
        interFrame.setLayout(new BorderLayout());
        interFrame.getContentPane().add(cPanel, BorderLayout.CENTER);
        interFrame.setSize(800, 600);
        desktop.add(interFrame);
        
        try {
            interFrame.setMaximum(true);
        } catch (PropertyVetoException e) {
            e.printStackTrace();
        }
        
        interFrame.setVisible(true);
        
        // Add components to frame
        frame.add(desktop, BorderLayout.CENTER);
        frame.add(statusBar, BorderLayout.SOUTH);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setExtendedState(frame.getExtendedState() | JFrame.MAXIMIZED_BOTH);
        frame.setVisible(true);
        
        // Start latency measurement
        startLatencyMeasurement();
    }
    
    private void startLatencyMeasurement() {
        pingScheduler = Executors.newSingleThreadScheduledExecutor();
        
        // Start periodic ping
        pingScheduler.scheduleAtFixedRate(() -> {
            if (cSocket != null && !cSocket.isClosed() && outputStream != null) {
                try {
                    outputStream.writeInt(Commands.PING_REQUEST.getAbbrev());
                    outputStream.writeLong(System.currentTimeMillis());
                    outputStream.flush();
                } catch (IOException e) {
                    updateLatencyDisplay(-1); // Connection lost
                }
            }
        }, 0, 1, TimeUnit.SECONDS); // Ping every second
        
        // Start thread to receive ping responses
        new Thread(() -> {
            try {
                while (!cSocket.isClosed()) {
                    int command = inputStream.readInt();
                    if (command == Commands.PING_RESPONSE.getAbbrev()) {
                        long sentTime = inputStream.readLong();
                        long rtt = System.currentTimeMillis() - sentTime;
                        currentLatency = rtt;
                        
                        SwingUtilities.invokeLater(() -> {
                            updateLatencyDisplay(rtt);
                        });
                    }
                }
            } catch (IOException e) {
                updateLatencyDisplay(-1);
            }
        }).start();
    }
    
    private void updateLatencyDisplay(long latency) {
        if (latency < 0) {
            latencyLabel.setText("Latency: Disconnected");
            latencyLabel.setForeground(Color.RED);
        } else {
            latencyLabel.setText(String.format("Latency: %d ms", latency));
            
            // Color coding
            if (latency < 30) {
                latencyLabel.setForeground(new Color(0, 150, 0)); // Dark green
            } else if (latency < 60) {
                latencyLabel.setForeground(Color.ORANGE);
            } else if (latency < 100) {
                latencyLabel.setForeground(Color.RED);
            } else {
                latencyLabel.setForeground(Color.MAGENTA); // Very high latency
            }
        }
    }
    
    public void setFPS(int fps) {
        SwingUtilities.invokeLater(() -> {
            fpsLabel.setText(String.format("FPS: %d", fps));
        });
    }
    
    @Override
    public void run() {
        try {
            outputStream = new DataOutputStream(cSocket.getOutputStream());
            inputStream = new DataInputStream(cSocket.getInputStream());
            
            drawGUI();
            
            InputStream in = cSocket.getInputStream();
            
            // Start screen receiving and event sending
            new ReceivingScreen(in, cPanel, this);
            new SendEvents(cSocket, cPanel, width, height);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void cleanup() {
        if (pingScheduler != null && !pingScheduler.isShutdown()) {
            pingScheduler.shutdown();
        }
    }
}